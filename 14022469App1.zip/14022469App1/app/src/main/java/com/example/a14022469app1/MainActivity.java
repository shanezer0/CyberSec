package com.example.a14022469app1;

import android.os.Bundle;

import android.app.Activity;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {
    EditText message, password;
    TextView result;
    Button enc, dec;
    String dectxt, encval, decval;
    String AES="AES";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        message = (EditText) findViewById(R.id.message);
        password = (EditText) findViewById(R.id.Password);
        result = (TextView) findViewById(R.id.outputText);
        enc = (Button) findViewById(R.id.encrypt);
        dec = (Button) findViewById(R.id.decrypt);
        enc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    dectxt =
                            encrypt(message.getText().toString(),
                                    password.getText().toString());
                    result.setText(dectxt);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        dec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    dectxt = decrypt(dectxt,
                            password.getText().toString());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Incorrect password, try again please", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
                result.setText(dectxt);
            }
        });
    }
    private String encrypt (String Data, String pass) throws
            Exception {
        SecretKeySpec key = generateKey(pass);
        Cipher c = Cipher.getInstance(AES);
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encVal = c.doFinal(Data.getBytes());
        encval = Base64.encodeToString(encVal,
                Base64.DEFAULT);
        return encval;
    }
    private String decrypt (String outputString, String pass)
            throws Exception {
        SecretKeySpec key = generateKey(pass);
        Cipher c = Cipher.getInstance(AES);
        c.init(Cipher.DECRYPT_MODE, key);
        byte[] decodedValue = Base64.decode(outputString,
                Base64.DEFAULT);
        byte[] decValue = c.doFinal(decodedValue);
        decval = new String(decValue);
        return decval;
    }
    private SecretKeySpec generateKey (String pass) throws
            Exception {
        final MessageDigest digest =
                MessageDigest.getInstance("SHA-256");
        byte[] bytes = pass.getBytes("UTF-8");
        digest.update(bytes, 0, bytes.length);
        byte[] key = digest.digest();
        SecretKeySpec secretKeySpec = new SecretKeySpec(key,
                "AES");
        return secretKeySpec;
    }
}
